---
title: "Com es calcula la indemnització per lumbàlgia després d’un accident de trànsit?"
date: 2025-03-01
draft: false
summary: "Lumbàlgia posttraumàtica: recuperació, seqüeles freqüents i claus del càlcul de la indemnització amb suport d’un informe mèdic pericial."
tags: ["lumbàlgia", "indemnització accident de trànsit", "lesions lumbars", "valoració mèdica", "peritatge mèdic"]
image: "/images/blog/lumbalgia-accidente.jpg"
---

## Lumbàlgia posttraumàtica: el més important

La **lumbàlgia després d’un accident** pot deure’s a contraccions brusques o a lesió discal. Tot i que moltes milloren en **4–8 setmanes**, algunes es **cronifiquen**.

> 🔗 Relacionat: <a href="https://jaumeblanch.com/ca/blog/secuelas-psicologicas-accidente/" class="underline text-primary hover:text-primary-dark">Seqüeles psicològiques</a>

---

## Seqüeles i documentació clau

- Dolor lumbar persistent.  
- Limitació de flexo-extensió.  
- Hèrnia discal posttraumàtica.

Conserva informes, imatges i rehabilitació: seran determinants en la **baremació**.

---

## Càlcul de la indemnització: importància del peritatge

Una <a href="https://jaumeblanch.com/ca/valoracio-de-lesions-en-accidents-de-trafic/" class="underline text-primary hover:text-primary-dark">valoració pericial</a> vincula la lesió amb el sinistre, mesura l’afectació funcional i sustenta la **quantia indemnitzatòria** amb <a href="https://jaumeblanch.com/ca/valoracio-medica-per-a-reclamacions-i-assegurances/" class="underline text-primary hover:text-primary-dark">informe mèdic pericial</a>.

> 👉 Amplia: <a href="https://jaumeblanch.com/ca/blog/secuela-neurologica-accidente-trafico/" class="underline text-primary hover:text-primary-dark">Seqüeles neurològiques</a>

---

## Conclusió i següent pas

Si pateixes **lumbàlgia després d’un accident**, demana una <a href="https://jaumeblanch.com/ca/valoracio-de-lesions-en-accidents-de-trafic/" class="underline text-primary hover:text-primary-dark">valoració de lesions</a> i prepara el teu <a href="https://jaumeblanch.com/ca/valoracio-medica-per-a-reclamacions-i-assegurances/" class="underline text-primary hover:text-primary-dark">informe pericial</a> amb el **Dr. Jaume Blanch** per **defensar la teva indemnització**. <a href="https://jaumeblanch.com/ca/#contact" class="underline text-primary hover:text-primary-dark">Contacta aquí</a>.
