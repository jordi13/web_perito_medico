---
title: "Fractura de clavícula en un accident de trànsit: recuperació, seqüeles i indemnització"
date: 2025-03-05
draft: false
summary: "Fractura de clavícula: temps de consolidació, seqüeles habituals i com un peritatge mèdic sòlid influeix en la teva indemnització."
tags: ["fractura clavícula", "accident de trànsit", "lesions òssies", "valoració mèdica", "peritatge mèdic"]
image: "/images/blog/fractura-clavicula-accidente.jpg"
---

## Com es produeix i quant tarda a consolidar?

Les **fractures de clavícula** són habituals en motoristes i ciclistes per impactes a l’espatlla. La consolidació sol ser de **6–12 setmanes**, segons el tipus de fractura i el tractament.

> 🔗 Relacionat: <a href="https://jaumeblanch.com/ca/blog/cervicalgia-accidente/" class="underline text-primary hover:text-primary-dark">Cervicalgia posttraumàtica</a>

---

## Seqüeles més freqüents

- Limitació de la mobilitat de l’espatlla.  
- Dolor crònic local.  
- Deformitat estètica.  
- Dificultat per fer esforços intensos.

---

## Informe pericial i indemnització

Una <a href="https://jaumeblanch.com/ca/valoracio-de-lesions-en-accidents-de-trafic/" class="underline text-primary hover:text-primary-dark">valoració pericial</a> és clau per:

- Acreditar la **relació causal** amb l’accident.  
- Quantificar la **limitació funcional** i el perjudici estètic.  
- Fonamentar la **indemnització** amb <a href="https://jaumeblanch.com/ca/valoracio-medica-per-a-reclamacions-i-assegurances/" class="underline text-primary hover:text-primary-dark">informe mèdic pericial</a>.

> 👉 També t’interessa: <a href="https://jaumeblanch.com/ca/blog/indemnizacion-lumbalgia-accidente/" class="underline text-primary hover:text-primary-dark">Indemnització per lumbàlgia</a>

---

## Conclusió i CTA

No **menystinguis** una fractura de clavícula. Protegeix la teva recuperació i reclamació: demana una <a href="https://jaumeblanch.com/ca/valoracio-de-lesions-en-accidents-de-trafic/" class="underline text-primary hover:text-primary-dark">valoració de lesions</a> amb el **Dr. Jaume Blanch** i prepara el teu <a href="https://jaumeblanch.com/ca/valoracio-medica-per-a-reclamacions-i-assegurances/" class="underline text-primary hover:text-primary-dark">informe pericial</a>. <a href="https://jaumeblanch.com/ca/#contact" class="underline text-primary hover:text-primary-dark">Sol·licita cita</a>.
