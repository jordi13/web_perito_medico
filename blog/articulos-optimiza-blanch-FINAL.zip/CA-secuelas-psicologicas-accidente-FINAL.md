---
title: "Seqüeles psicològiques després d’un accident de trànsit: com es valoren mèdicament"
date: 2025-04-10
draft: false
summary: "Ansietat, TEPT i altres danys psicològics després d’un accident: com s’avaluen mèdicament i com reforçar la teva reclamació amb un informe pericial."
tags: ["seqüeles psicològiques", "accident de trànsit", "estrès posttraumàtic", "valoració mèdica", "informe pericial"]
image: "/images/blog/secuelas-psicologicas.jpg"
---

## Impacte psicològic després d’un accident

A més de les lesions físiques, són freqüents **ansietat**, **TEPT**, depressió reactiva i fòbies relacionades amb la conducció. Impacten en el treball, el descans i la vida social.

> 🔗 Relacionat: <a href="https://jaumeblanch.com/ca/blog/indemnizacion-lumbalgia-accidente/" class="underline text-primary hover:text-primary-dark">Indemnització per lumbàlgia</a>

---

## Evolució i signes d’alerta

Els símptomes poden disminuir amb teràpia o **cronificar-se**. Si interfereixen en la teva vida diària, busca ajuda **multidisciplinària** (medicina pericial + psicologia/psiquiatria).

---

## Valoració pericial del dany psíquic

Una <a href="https://jaumeblanch.com/ca/valoracio-medica-per-a-reclamacions-i-assegurances/" class="underline text-primary hover:text-primary-dark">valoració mèdica per a reclamacions i assegurances</a> relaciona els símptomes amb el sinistre, gradua la incapacitat i sustenta la **indemnització pel dany moral**.

> 👉 També et pot interessar: <a href="https://jaumeblanch.com/ca/blog/secuela-neurologica-accidente-trafico/" class="underline text-primary hover:text-primary-dark">Seqüeles neurològiques</a>

---

## Conclusió i següent pas

El **dany psicològic** és tan rellevant com el físic. Demana una <a href="https://jaumeblanch.com/ca/valoracio-medica-per-a-reclamacions-i-assegurances/" class="underline text-primary hover:text-primary-dark">valoració mèdica pericial</a> amb el **Dr. Jaume Blanch** i <a href="https://jaumeblanch.com/ca/#contact" class="underline text-primary hover:text-primary-dark">sol·licita la teva cita</a> per **defensar els teus drets**.
